class Demo
{
 void show()
  {
   System.out.println("Curent obje="+this);
   }
 static  void disp()
  {
   System.out.println(this);
   }
 public static void main(String []a)
 {
  Demo ob=new Demo();
  Demo ob2=new Demo();
   ob.show();
    ob2.show();
    ob.disp();
    }
 }
