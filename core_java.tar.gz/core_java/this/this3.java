class Demo
{
 int id;
String name;

Demo(int id,String name)
{
 this.id=id;
this.name=name;
}
void show()
{
 System.out.println(id+" "+name);
}
public static void main(String arr[])
{
 Demo ob=new Demo(7,"Ankit");
 ob.show();
}
}
 
