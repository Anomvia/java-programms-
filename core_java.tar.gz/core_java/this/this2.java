class Demo
{
 int id;
 String name;
  void read(int id,String name)
   {
    id=id;
    name=name;
    }
    void show()
     {
      System.out.println("id="+id);
       System.out.println("Name="+name);
      }
 public static void main(String arr[])
 {
  Demo ob=new Demo();
   ob.read("101","Duggu");
   ob.show():
    }
  }
