class Demo
{
    int a;
    int b;
    Demo()
    {
        a = 10;
        b = 20;
    }
      // Method that receives 'this' keyword as parameter
    void display(Demo obj)
    {
        System.out.println("Display call....."); }
  // here get returns current class instance
  
    void get()
    {
        display(this);
    }
 
    public static void main(String[] args)
    {
        Demo ob = new Demo();
        ob.get();
    }
}
