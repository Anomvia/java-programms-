class Demo
{ 
 Demo()
  {
   System.out.println("Hell ofrom Default Cons");
  this(10);
  } 
  Demo(int a)
  {
      System.out.println("Hello from single int cons");
   }
   
public static void main(String arr[])
{ 
  Demo ob=new Demo();
 }
 }
