import java.io.*;
class Test3
{
public static void main(String arr[])
{
try
{
 File f=new File("E:\\web","abc.txt");
f.createNewFile();
}catch(Exception e){}
}
}