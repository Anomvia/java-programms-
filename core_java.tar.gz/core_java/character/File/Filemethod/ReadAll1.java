import java.io.*;
class Test1
{
 public static void main(String arr[])
{
 int count=0;
 long length;
File f=new File("c:\\java");
 String s[]=f.list();
 length=f.length();
 for(String s1:s)
{
 count++;
System.out.println(s1);
 }
System.out.println("The Total No OF file=" + count);
System.out.println("File Length="+length);
}
}