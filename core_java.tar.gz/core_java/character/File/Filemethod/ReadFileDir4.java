import java.io.*;
class F4
{
public static void main(String arr[])
{
 int c1=0,c2=0;
 File f=new File("c:\\java");
 String s[]=f.list();
 for(String s1:s)
{
 File f1=new File(f,s1);
 {
 if(f1.isFile())
{
 c1++;
 System.out.println(s1);
}
else if(f1.isDirectory())
{
 c2++;
String s3[]=s1;
}
}
}
System.out.println("Derectory are:-);
for(String s4:s3)
{
System.out.println(s4);
}
System.out.println("Total No Of Of File="+c1);
System.out.println("The Total No of Directry="+c2);
}
}