import java.io.*;
class Test1
{
 public static void main(String arr[])
{
 int count=0;
boolean b=false;
 long length;
File f=new File("c:\\del");
b= f.delete();
if(b)
{
 System.out.println("File Successfully deleted");
}
 String s[]=f.list();
 length=f.length();
 for(String s1:s)
{
 count++;
System.out.println(s1);
 }
System.out.println("The Total No OF file=" + count);
System.out.println("File Length="+length);
}
}