import java.io.*;
class Test
{
public static void main(String ar[]) throws Exception
{
 File f=new File("xyz.txt");
 System.out.println(f.exists());
//  f.createNewFile();
//System.out.println(f.exists());
}
}