import java.io.*;
class FileWrite2
{
public static void main(String arr[]) throws IOException
{
FileWriter fw=new FileWriter("Ab1c.txt",true);
 fw.write(100);
fw.write("Hello Class  \n");
fw.write('\n');
char c[]={'N','I','I','T'};
fw.write(c);
fw.write('\n');
fw.flush();
fw.close();
}
}