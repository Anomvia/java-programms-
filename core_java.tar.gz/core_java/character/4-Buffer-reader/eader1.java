import java.io.*;
class Buffread {
   public static void main(String arr[]) 
   {
       BufferedReader br = null;
       try{	
           br = new BufferedReader(new FileReader("abc.txt"));
	   System.out.println("Reading the file using readLine() method:");
	   String  rline = br.readLine();
	   while (rline != null) 
    	   {
	      System.out.println(rline);
	      rline = br.readLine();
	   }
                 }catch(Exception e)
                 {
                   e.printStackTrace();
                  }
            }
 }
