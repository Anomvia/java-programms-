 class Abc
{
    public void read()
    {
        System.out.println(" Hello Abc class");
    }
}
 class custom {
 public static void main(String[] args) 
        { 
              Abc p=new Abc()
             {
               public void read()
               {
                   System.out.println(" Hello from anonymus inner class");   
               }
            };
            p.read();
        
     Abc p2=new Abc();
     p2.read();
     Abc p3=new Abc()
      {
       public void read()
       {
           System.out.println("Second anonymus Inner class");
       }
     };
     p3.read();
     //=====================================================
            System.out.println(p.getClass().getName());
            System.out.println(p2.getClass().getName());
            System.out.println(p3.getClass().getName());
} }

