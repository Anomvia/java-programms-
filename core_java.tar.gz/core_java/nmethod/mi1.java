//Basic for inner 
class Abc
{
  void  read()
  {
  class Inner
  {
  void add(int a,int b)
  {
 System.out.println(a+b);
    }
  }//inner class
Inner i=new Inner();
i.add(10,20);
i.add(50,70);
  }  //read method close
 public static void main(String arr[])
 {
  Abc ob=new Abc();
   ob.read();
   }
 }
