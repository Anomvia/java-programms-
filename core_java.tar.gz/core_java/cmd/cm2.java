class Demo
{
 public static void main(String arr[])
  {
   for(int i=0;i<=arr.length;i++)
   {
   System.out.println(arr[i]);
   
      }
    }
 }
