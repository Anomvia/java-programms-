class Demo
{
 public static void main(String arr[])
  {
   String a=arr[0];
   String b=arr[1];
   int k=Integer.parseInt(a);
   int l=Integer.parseInt(b);
   System.out.println(k+l);
    }
 }
