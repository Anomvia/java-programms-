import java.util.Scanner;
class Demo
{ 
public static void main(String arr[])
 {
   Scanner sc=new Scanner(System.in);
   String name =sc.next();
    System.out.println("Name="+name);
   String add=sc.nextLine();
    System.out.println("Address="+add);
    }
 }
