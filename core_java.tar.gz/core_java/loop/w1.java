class Abc
{
 public static void main(String arr[])
  {
   int i=1;
    while(i<=10)
     {
       System.out.println("Hello");
       i++;
      }
    }
 }
