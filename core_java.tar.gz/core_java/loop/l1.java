class Demo
{
 public static void main(String arr[])
  {
  int i=1;
  for(System.out.println("inti");i<=5;i++)
   {
    System.out.println(" "+i);
    }
   } 
}
