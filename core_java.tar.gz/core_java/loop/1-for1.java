//declarative stmt
class Demo {
   public static void main(String arr[])
  {
     for(int i=1;i<10;i++)
     int a=10; 
      System.out.println("hi");
     System.out.println("hiiiiiiiiii");
    }
 }
