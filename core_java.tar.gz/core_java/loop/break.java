class Demo
{
 public static void main(String arr[])
  {
   int i;
   for(i=1;i<40;i++)
    {
    if(i>=38)
    {
     System.out.println("!!! Alert.........");
       System.out.println("Temp is high, So we r");
       System.out.print("going to shut down machine");
       break;
      }
     System.out.println("MAchine is working properly-Temp="+i);
         
       }//for
    }
 }
