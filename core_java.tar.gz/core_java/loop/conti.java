class Demo
{
 public static void main(String arr[])
  {
   int i;
   for(i=1;i<30;i++)
    {
    if(i<=26)
    {
     System.out.println("!!! Alert.........");
      System.out.println("Temp is low, pls wait"); 
             continue;
             }
     System.out.println("MAchine is ready, pls select your choice");
         
       }//for
    }
 }
