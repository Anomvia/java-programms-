class Abc
{
 public static void main(String arr[])
  {
   int i=1;
    while()
     {
       System.out.println("Hello");
       i++;
      }
    }
 }
