class Demo
{
 public static void main(String arr[])
  {
  int i=1;
  for(System.out.println("inti"); ;System.out.println("hii") )
   {
    System.out.println(" "+i);
    }
   } 
}
