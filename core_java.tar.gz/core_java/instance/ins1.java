class Demo1
{

 }
 class Demo2
 {
     
}
class Demo3
{
    
}
class Ins_Demo 
{
    public static void main(String arr[]) {
        Demo1 ob1=new Demo1();
        Demo2 ob2=new Demo2();
        Demo3 ob3=new Demo3();
         if(ob1 instanceof Demo1)
         {
             System.out.println("ob1 is instance of Demo1");
         }
      if(ob1 instanceof Object)
     {
    System.out.println("Object is super class");
      }
    }
}
