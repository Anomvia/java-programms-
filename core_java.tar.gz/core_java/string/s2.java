class Demo
{
 void add()
  {
  String s1=new String(“abc”);
String s2=new String(“abc”);
System.out.println(s1==s2);  
System.out.println(s1.equals(s2)); 

StringBuffer  sb1=new StringBuffer(“abc”);
StringBuffer sb2=new StringBuffer(“abc”);
System.out.println(sb1==sb2); 
System.out.println(sb1.equals(sb2));   
}
public static void main(String arr[])
{
 Demo ob=new Demo();
 ob.add();
 }}
