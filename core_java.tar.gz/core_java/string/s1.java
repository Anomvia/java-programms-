class Demo
{
 public static void main(String arr[])
 {
   String s1="abc";
   String s2="abc";
   String s3="abc";
     System.out.println(s1); 
   System.out.println(s2);
    System.out.println(s3);
    s1.concat("class");
   System.out.println(s1); 
   s1=s1.concat("class");
   System.out.println(s1); 
 
   }
 }
