import java.util.*;
class Stringtokenizerdemo
{
public static void main(String args[])
{
String str="Hello class how are you";
StringTokenizer st=new StringTokenizer(str," ");
System.out.println("The tokens are: ");
while(st.hasMoreTokens())
String one=st.nextToken();
System.out.println(one);
}
}
}
