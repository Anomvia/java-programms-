class Demo
{
void show(byte a,byte b)
{
  System.out.println(" byte a and b method is called");
  
 }
 void show(int a,int b)
  {
   System.out.println(" Int a and b method is called");
   }
  void show(long  a, long b)
  {
   System.out.println(" long a and b method is called");
   }
 
 public static void main(String arr[])
  {
  // a=10, b=30;
  Demo ob=new Demo();   
     ob.show(10,20);
    }
 }  
