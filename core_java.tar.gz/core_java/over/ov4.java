class Demo
{
   public static void main(int a)
  {
   System.out.println(" Int-Main method call ");
   }
 public static void main(String b)
  {
   System.out.println("str-Main method call ");
   }

 public static void main(String a[])
  {
    System.out.println("Main method call ");
      main(10);
      main("hello");
    }
 }
