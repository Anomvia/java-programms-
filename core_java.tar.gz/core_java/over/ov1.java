class Demo
{
 void disp(int a)
 {
  System.out.println(a);
  }
   void disp(int a,int b)
    {
      System.out.println(a+"  "+b);
      }
      void disp(int a,int b,int c)
      { 
      System.out.println(a+"  "+b+ "  "+c );
      }
 public static void main(String arr[])
  {
   Demo ob=new Demo();
   ob.disp(10);
   ob.disp(10,20);
   ob.disp(10,20,30);
  }
 }
