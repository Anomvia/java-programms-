class Demo
{
void show(int a, float b)
{
  System.out.println(" byte a and b method is called");
  
 }
 void show(float a,int b)
  {
   System.out.println(" Int a and b method is called");
   }
  
 public static void main(String arr[])
  {
  // a=10, b=30;
  Demo ob=new Demo();   
     ob.show(10,20);
    }
 }  
