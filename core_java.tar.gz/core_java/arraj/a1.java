class Abc
{
 public static void main(String sarr[])
  {
 byte[] a1=new byte[2];
 short[] a2=new short[2];
 long[] a3=new long[2];
 int[] a4=new int[2];
char[] a5=new char[2];
 float[] a6=new float[2];
 double[] a7=new double[2];
 boolean[] a8=new boolean[2];
 System.out.println("Name of class for byte a"+a1.getClass().getName());
 System.out.println("Name of class for  short a"+a2.getClass().getName());
 System.out.println("Name of class for long a"+a3.getClass().getName());
 System.out.println("Name of class for int a"+a4.getClass().getName());
 System.out.println("Name of class for char a"+a5.getClass().getName());
System.out.println("Name of classfor float a"+a6.getClass().getName());
 System.out.println("Name of class for double a"+a7.getClass().getName());
 System.out.println("Name ofclassfor boolean a"+a8.getClass().getName());
    }
 }
