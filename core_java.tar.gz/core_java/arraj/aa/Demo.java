import java.util.*;
class Demo
{
 public static void main(String arr[])
 {
  Scanner sc=new Scanner(System.in);
  int[][] a=new int[2][3];
  System.out.println("pls enter arra yelements");
  int i,j;
  for(i=0;i<a.length;i++)
   { 
    for(j=0;j<a[i].length;j++)
     {
      a[i][j]=sc.nextInt();
        }
   } //outer
   System.out.println("Array Element are ");  
 for(i=0;i<a.length;i++)
   { 
    for(j=0;j<a[i].length;j++)
     {
      System.out.print(" "+a[i][j]);
        }
        System.out.println();
   } //outer
 
 
  }  
} 
