import java.util.Scanner;
class Abc
{
 public static void main(String sarr[])
  {
  Scanner sc=new Scanner(System.in);
 int i;
 int[] a=new int[5];
 System.out.println("pls enter array elements");
  for(i=0;i<a.length;i++)
   {
    a[i]=sc.nextInt();
    }
    System.out.println("Array elements are");
     for(i=0;i<a.length;i++)
     {
      System.out.print( "  "+a[i] );
      }
 }     }
