import java.io.*;
class FileWrite
{
public static void main(String arr[]) throws IOException
{
FileWriter fw=new FileWriter("Ab1c.txt");
 fw.write(100);
fw.write("Hello Class  \n");
fw.write('\n');
char c[]={'H','E','L','L','O'};
fw.write(c);
fw.write('\n');
fw.flush();
fw.close();
}
}