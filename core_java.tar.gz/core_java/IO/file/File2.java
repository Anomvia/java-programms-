import java.io.*;
class Dir
{
public static void main(String arr[])
{
 File f=new File("JavaFile2");
 //System.out.println(f.exists());
 //f.mkdir();
System.out.println(f.exists());
}
}