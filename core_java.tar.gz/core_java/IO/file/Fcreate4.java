import java.io.*;
class Fdemo
{
 public static void main(String arr[]) throws IOException
{
Boolean b;
 File f=new File("root");
 f.mkdir();
File f1=new File("root","Demo1.txt");
File f2=new File(f,"Demoemo1.txt");
f1.createNewFile();
b=f1.exists();
if(b)
{
System.out.println("SuccessFully Created");
}
}
}
