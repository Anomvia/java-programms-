class Abc
{
 private Abc()
 {
  }
 }
 class Demo extends Abc
 {
  public static void main(String arr[])
   {
    }
  }
