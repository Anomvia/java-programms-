class Demo
{
     private static Demo d=new Demo();
     
     private Demo()
     {
     System.out.println("Constructor call");
     }
     public static Demo getDemo()
     {
         return  d; 
         }
}
 class SingletenDemo
  {
    public static void main(String []arr) {
        
         Demo o=Demo.getDemo();
       Demo d2=Demo.getDemo();
       Demo d7=Demo.getDemo();
      //  Demo d3=new Demo();
        // Demo d5=new Demo();
    }
}
