abstract class Abc
{
  abstract void speed();
   }
  class Demo extends Abc
  {
  void speed()
  {
   System.out.println("Now this is comp method"); 
  }
  
 public static void main(String arr[])
 {
  Demo ob=new Demo(); 
   ob.speed();
   }
 }
