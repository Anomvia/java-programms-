abstract class Abc
{
     abstract void speed();
      abstract void  distance();
    void comp()
    {
     System.out.println("Abstract class complete method"); 
    }    
   }
  abstract class Demo extends Abc
  {
    void speed()
  {
   System.out.println("Now this is comp method"); 
   }
 }
 
class Demo2 extends Demo
 {
    void distance()
  {
   System.out.println("Distance complete");
   }
 
 public static void main(String arr[])
 {
   Demo2 ob=new Demo2(); 
    ob.speed();
    }
 }
