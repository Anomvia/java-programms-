public class Test
{
 void show()
 {
  System.out.println("Welcome in java World");
  }
 }
public class Demo
{
 public static void main(String a[])
 {
  Test ob=new Test();
  ob.show();
   System.out.println("Hello class"); 
    }
 }
