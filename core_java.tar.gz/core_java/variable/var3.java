class Demo
{

 public static void main(String arr[])
  {
  int k;
  System.out.println( 
