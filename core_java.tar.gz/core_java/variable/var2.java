class Demo
{
 int a;
 float b;
 double d;
boolean k;
 public static void main(String arr[])
  {
   Demo ob=new Demo();
   System.out.println("Value of def int-"+ob.a);
      System.out.println("Value of def  float-"+ob.b);
         System.out.println("Value of def double-"+ob.d);
            System.out.println("Value of def boolean-"+ob.k);
    } 
 }
