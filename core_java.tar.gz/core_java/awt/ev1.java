import java.awt.*;
import java.awt.event.*;
class AcEvent extends Frame implements ActionListener
{
TextField tf;
AcEvent()
{

tf=new TextField();
tf.setBounds(60,50,170,20);
Button b=new Button("click me");
b.setBounds(100,120,80,30);
//register listener
b.addActionListener(this);
//add components and set size, layout and visibility
add(b);
add(tf);
setSize(400,300);
setLayout(null);
setVisible(true);
}
public void actionPerformed(ActionEvent e){
tf.setText("Hello Class ");
}
public static void main(String arr[]){
AcEvent ob=new AcEvent();
  }
}
