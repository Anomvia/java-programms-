import java.awt.*;
import java.awt.event.*;
 class LabelExample extends Frame implements ActionListener
{
TextField tf; 
Label l; 
Button b;
LabelExample()
{
tf=new TextField();
tf.setBounds(50,50, 150,20);
l=new Label();
l.setBounds(50,100, 250,20);
b=new Button("Click");
b.setBounds(50,150,60,30);
b.addActionListener(this);
add(b);add(tf);add(l);
setSize(400,400);
setLayout(null);
setVisible(true);
}
public void actionPerformed(ActionEvent e) {
try{
String s=tf.getText();
l.setText(s);
}catch(Exception e2){System.out.println(e2);}
}
public static void main(String[] args) 
{
LabelExample ob=new LabelExample();
}
}
