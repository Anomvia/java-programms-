import java.awt.*;
 class Frame2 extends Frame{
    Frame2(){  
        Button b=new Button("Submit"); 
        
        // setbound button position on screen
         b.setBounds(50,50,50,50);  
         add(b); 
        // Frame width and height
        setSize(500,300); 
        //Frame Title
        setTitle("Frame By Extending Frame"); 
      //  setLayout(new FlowLayout());
        
        /* By default frame is not visible so  we are setting the visibility to true 
         to make frame  visible.
         */
        setVisible(true);  
    }  
    public static void main(String arr[])
    {  
         Frame2 fr=new Frame2();  
    }
}
