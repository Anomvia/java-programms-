import java.awt.*;
class First
{
First()
{
Frame f=new Frame();
Button b=new Button("click me");
b.setBounds(130,100,80,30);
f.add(b);
f.setSize(300,300);
f.setLayout(null);
f.setVisible(true);
f.setTitle("Frame By using instance of  Frame"); 
}
public static void main(String arr[]){
First f=new First();
}}
