class Demo
{
  public static void main(String arr[]){
   try
   {
     int a=10/0;
     int ar[5]={1,2,3,4,5};
      System.out.println(ar[7]);
     }catch(ArithmeticException | ArrayIndexOutOfBoundsException e)
      {
       System.out.println("\n NOw it handle both AR and AI Exception");
         }
 } }
 // ArithmeticException
 //ArrayIndexOutOfBoundsException
