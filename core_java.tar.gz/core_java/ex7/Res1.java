import java.io.*;
class Demo
{
public static void main(String arr[])
{
try{
String str;
//her we r opening file in read mode using BufferedReader stream
BufferedReader br=new BufferedReader(new FileReader("abc.txt"));
while((str=br.readLine())!=null)
 {
System.out.println(str);
 }
   br.close();	//by usinng clos() closing BufferedReader stream
   }catch(IOException e)
    { 
      System.out.println("exception Occure");  }
    }
}
