import java.io.*;
class Demo
{
public static void main(String arr[])
{
try(BufferedReader br=new BufferedReader(new FileReader("abc.txt")))
{
 String str;  
  while((str=br.readLine())!=null)
   {
  System.out.println(str);
   }
  }catch(IOException ie)
  { 
   System.out.println("exception");  } 
   }
 }
 
 //NOTE: In the above example, we do not need to explicitly call close() method to close BufferedReader stream Object.
