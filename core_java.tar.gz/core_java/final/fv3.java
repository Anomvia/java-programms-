class Demo
{

{
System.out.println("Instance block");
 }
 Demo()
 {
  System.out.println("DEfault constructor run");
  } 
 
{
int a=20,b=30,c;
System.out.println("2nd block block="+(a+b));
 }
  public static void main(String arr[])
 {
  Demo ob=new Demo();
    }
} 
