class Demo
{
final int a;
Demo()
{
 a=30;
 }
void show()
{
//a=30;  //cannot assign a value to final variable a
System.out.println("Value of a="+a);
 }
 public static void main(String arr[])
 {
  Demo ob=new Demo();
  ob.show();
  }
} 
