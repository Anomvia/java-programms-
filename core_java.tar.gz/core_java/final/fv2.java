class Demo
{
final int a;

{
 a=20;
 }
 
void show()
{
//a=30;  //cannot assign a value to final variable a
System.out.println("Value of a="+a);
 }
 public static void main(String arr[])
 {
  Demo ob=new Demo();
  ob.show();
  }
} 
