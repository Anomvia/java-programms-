    @FunctionalInterface  
    interface Drawable{  
        public void draw();  
    }  
      
    class Lmd2 {  
        public static void main(String arr[]) {  
            int b=10;  
              
            //with lambda  
           Drawable d2()->{  
                System.out.println("REsult"+b);  
            };  
            d2.draw();  
        }  
    }  
