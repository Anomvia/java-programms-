    interface Drawable
    {  
        public void draw();  
    }  
    class Lam1
    {  
        public static void main(String arr[]) {  
            int b=10;  
      
            //Here drawable implementation using anonymous class  
            Drawable d=new Drawable(){  
                public void draw()
               {
               System.out.println("Result "+b);
                     }  
            };  
            d.draw();  
        }  
    }  
