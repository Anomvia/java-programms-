interface A
{
 static default void  show()
  {
 System.out.println("Hello class");
     }
  }
class Demo implements A
{
 
 public static void main(String arr[])
 {
 Demo ob=new Demo();
// ob.show();
  A.show();
  }
}
