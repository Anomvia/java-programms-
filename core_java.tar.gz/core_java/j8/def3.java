interface A
{
 default void  show()
  {
 System.out.println("Hello class");
     }
  }
  interface B
  {
  default void  show()
  {
 System.out.println("Hello class");
     }
  }

class Demo implements A,B
{
 public void  show()
  {
 System.out.println("Hello class");
     }
  

 public static void main(String arr[])
 {
 Demo ob=new Demo();
 ob.show();
  }
}
