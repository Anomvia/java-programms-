class F1
{
 public static void main(String arr[])
{
 try
{
 System.out.println("Try Block");
}
catch(Exception e)
{
  System.out.println("Catch Block");
}
finally
{
  System.out.println("Finally Block");
}
}
}
// Try Block
//Finally Block
