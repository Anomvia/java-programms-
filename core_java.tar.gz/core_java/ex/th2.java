import java.util.*;
class Demo1
{
	void check(int marks) throws Exception
	{
	if(marks<0)
	{
	 throw new Exception("Enter only Positive No");
		 }
		 else
		 {
		System.out.println("Passed....");
		 }
	}
	public static void main(String arr[])
	{
		Demo1 ob=new Demo1();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter MArks");
		int m=sc.nextInt();
     try
      { 
		ob.check(m);
     }catch(Exception e) 
      {
       e.printStackTrace();
       }
	}
}
