class FF
{
 public static void main(String arr[])
{
 try
{
 System.out.println("Try Block");
 System.out.println(10/0);
}
catch(NullPointerException e)
{
System.out.println("Hello"+e);
  System.out.println("Catch Block");
}
finally
{
  System.out.println("finally Block Block");
}
}
}
