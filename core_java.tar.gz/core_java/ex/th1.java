 class Demo{
 
 void show() throws Exception
 {
  throw new ArithmeticException("Hello class Don,t devide by zero");
   }
 public static void main(String[] args) 
 {
    
     Demo ob=new Demo();
     try
     {
      ob.show();
      } catch(Exception e)
      {
      e.printStackTrace();
 
  } }}
