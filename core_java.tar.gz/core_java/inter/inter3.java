class D
{
    interface Message
{
       void dispaly();
  }
}

class NDemo implements D.Message
{
   public void dispaly()
{
     System.out.println("Nested Interface Within Class");
   }

  public static void main(String arr[])
{
     D.Message message = new NDemo();//upcasting here
     message.dispaly();
  }
}
