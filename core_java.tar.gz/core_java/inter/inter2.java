interface Developer
{  
void disp();
}  
interface Manager
{
void disp();
} 

class Employee implements Developer, Manager
{
public void disp()
{
System.out.println("Hello Good Morning");  
}

public void show()
{
System.out.println("How are you ?");  
}
public static void main(String args[])
{
Employee obj=new Employee();
obj.disp();
obj.show();
}  
} 
