    import java.io.FileInputStream;
    import java.io.ObjectInputStream;
     
    class DeserDemo 
    {
     public static void main(String[] args)throws Exception
    {   
     ObjectInputStream ois= new ObjectInputStream(new FileInputStream("data.txt"));
          SerDemo obj= (SerDemo)ois.readObject();
          System.out.println(obj.getAddress());
     
        }
    }



