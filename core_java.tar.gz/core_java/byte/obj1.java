    import java.io.FileOutputStream;
    import java.io.ObjectOutputStream;
    import java.io.Serializable;
     
     class SerDemo implements Serializable {
     
        String name;
        String phonum;
        String address;
        int pin;
     
       public String getName() {
           return name;
        }
     
        public void setName(String name) {
            this.name = name;
        }
     
        public String getPhonum() {
            return phonum;
       }
     
        public void setPhonum(String phonum) {
            this.phonum = phonum;
        }
     
       public String getAddress() {
            return address;
        }
     
        public void setAddress(String address) {
            this.address = address;
        }
     
       public int getPin() {
            return pin;
        }

      public void setPin(int pin) {
            this.pin = pin;
        }
     
    public static void main(String[] args)throws Exception{
     
        SerDemo emp= new SerDemo();
        emp.setName("Duggu");
        emp.setAddress("Race course, Road Indore");
        emp.setPhonum("09-9999999");
        emp.setPin(45205);
     
        ObjectOutputStream oos= new ObjectOutputStream(new
        FileOutputStream("data.txt"));
     
        oos.writeObject(emp);
     
    }
    }


`