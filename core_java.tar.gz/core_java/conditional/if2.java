import java.util.Scanner;
class Demo
{
 public static void main(String arr[])
  {
   Scanner sc=new Scanner(System.in);
    System.out.println("pls enter age");
   int age=sc.nextInt();
    if(false)
         int a=20;  //declaration is not allowed
      else
   System.out.println("Sorry!!!You r not eligible");
   System.out.println("Sorry!!!You r not eligible");
   System.out.println("Sorry!!!You r not eligible");
             }
         }
