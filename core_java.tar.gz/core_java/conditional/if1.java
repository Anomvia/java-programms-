import java.util.Scanner;
class Demo
{
 public static void main(String arr[])
  {
   Scanner sc=new Scanner(System.in);
    System.out.println("pls enter age");
   int age=sc.nextInt();
    if(age>=18)
     {
      System.out.println("You r eligible");
      }else
      {
      System.out.println("Sorry!!!You r not eligible");
     
        }
    }
 }
