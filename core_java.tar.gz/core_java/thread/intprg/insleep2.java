class Threadm extends Thread
{
 int total=0;
 public void run()
 {
 for(int i=1;i<=100;i++)
 {
 total=total+i;
  }  
  }//run
 }
class MyThread
{
public static void main(String arr[]) throws InterruptedException
{
 Threadm b=new Threadm();
 b.start();
Thread.sleep(1000);
 System.out.println(b.total);
  }
