	class Threadm extends Thread
	{
	 int total=0;
	 public void run()
	 {
	 for(int i=1;i<=100;i++)
	 {
	 total=total+i;
	  }  
	  //here 1000 lines of code ?
	  }//run
	 }
	class MyThread
	{
	public static void main(String arr[])throws InterruptedException
	{
	 Threadm b=new Threadm();
                  b.start();
	 b.join();
	 System.out.println(b.total);
	  }
       }
