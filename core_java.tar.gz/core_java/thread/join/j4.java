class Testj 
{
public static void main(String arr[]) throws InterruptedException
{
 Thread.currentThread().join();
 System.out.println("Hello");
}
}