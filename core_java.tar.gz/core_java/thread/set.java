class Mythread extends Thread
{
void show()
{
 System.out.println(Thread.currentThread().getName());
}
}
class Demo
{
 public static void main(String arr[])
{
 System.out.println(Thread.currentThread().getName());
 Mythread th=new Mythread();
  th.show();
System.out.println(th.getName());
} 
 }
 
