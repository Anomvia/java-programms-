class Display 
{
 public void wish(String name)
{
 // More Lies of Code
System.out.println("Non Synchronised Block");
 synchronized(this)
{
 for(int i=0;i<=5;i++)
{
 System.out.print("Hello class");
 try
{
 Thread.sleep(500);
}catch(Exception e){}
System.out.println(name);
}
 }
//More Line of Code that is not Synchronised
}
}
class MyThread extends Thread
{
 Display d;
String name;
MyThread(Display d,String name)
{
this.d=d;
this.name=name;
}
public void run()
{
d.wish(name);
}
}

class SyncBlock
{
 public static void main(String arr[])
{
 Display d=new Display();
MyThread t1=new MyThread(d,"Duggu");
MyThread t2=new MyThread(d,"khushi");
 t1.start();
 t2.start(); 
}
}
