class MyThread extends Thread
{
}
class Testp
{
public static void main(String arr[])
{
System.out.println("Main Thread peiority="+ Thread.currentThread().getPriority());
MyThread t=new MyThread();
 System.out.println(t.currentThread().getPriority());

}
}
