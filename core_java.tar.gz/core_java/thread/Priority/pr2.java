class MyThread extends Thread
{
 public void run()
{
 for(int i=0;i<10;i++)
{
 System.out.println("Sub Class");
}
} }
class Threadp
{
 public static void main(String arr[])
{
 MyThread t=new MyThread();
t.setPriority(10);
t.start();
for(int i=0;i<10;i++)
{
 System.out.println("Main Thread");
}
}
}