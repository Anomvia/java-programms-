class MyThread extends Thread
{
}
class Testp
{
public static void main(String arr[])
{
 System.out.println(Thread.currentThread().getPriority());
Thread.currentThread().setPriority(12);
MyThread t=new MyThread();
System.out.println(t.getPriority());
}
}
