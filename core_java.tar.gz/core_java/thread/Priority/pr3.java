 class ThreadPriority extends Thread {

 public void run() {

   String Name = Thread.currentThread().getName();
   Integer Prio = Thread.currentThread().getPriority();
	 
   System.out.println(Name + " has priority " + Prio);
 }

 public static void main(String arr[]) throws InterruptedException 
{

   ThreadPriority t1= new ThreadPriority();
   ThreadPriority t2 = new ThreadPriority();
   ThreadPriority t3 = new ThreadPriority();

   t1.setPriority(Thread.MAX_PRIORITY);	
   t2.setPriority(Thread.MIN_PRIORITY);	
   t3.setPriority(Thread.NORM_PRIORITY);	
  
  
   t2.start();
  t1.start(); 
  t3.start();
   
 }
}
