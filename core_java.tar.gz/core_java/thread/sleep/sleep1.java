class S1
{
public static void main(String arr[])throws InterruptedException
{
 for(int i=1;i<=10;i++)
{
 System.out.println("Hello"+i);
 Thread.sleep(3000);
 } }
}
