class MyThread extends Thread
{
 public void run()
{

for(int i=0;i<100;i++)
{
 System.out.println("Sub Thread"+i);
}
System.out.println("Now Thread is going in sleeping state");
 try
{
Thread.sleep(1000);
}
 catch(InterruptedException e)
{
 System.out.println("Threadis Interrupting");
}
} }
class ThreadSleepDemo
{
public static void main(String arr[])
{
 MyThread t=new MyThread();
 t.start();
t.interrupt();
System.out.println("End of Main Thread");
}
}
