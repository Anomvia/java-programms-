class MyThread extends Thread
{
 public void run()
{
try
{
for(int i=0;i<10;i++)
{
 System.out.println("Sub Thread");
} }
 catch(Exception e)
{
 System.out.println("Threadis Interrupting");
}
} }
class ThreadSleepDemo
{
public static void main(String arr[])
{
 MyThread t=new MyThread();
 t.start();
t.interrupt();
System.out.println("End of Main Thread");
}
}
