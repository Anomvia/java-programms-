class Tostr
{
 String name;
int rollno;
Tostr(String name,int rollno)
{
 this.name=name;
this.rollno=rollno;
}
public String toString()
{
 // return name+"...."+rollno;
return "This is Student with the name:"+name+"...."+rollno;
}
public static void main(String arr[])
{
 Tostr s1=new Tostr("Duggu",101);
Tostr  s2=new Tostr("Sulabh",102);
System.out.println(s1);
System.out.println(s1.toString());
System.out.println(s2);
}
}
