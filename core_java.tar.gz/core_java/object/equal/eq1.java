class Equal1
{
String name;
int rollno;
Equal1(String name,int rollno)
{
 this.name=name;
this.rollno=rollno;
}
public static void main(String arr[])
{
 Equal1 ob1=new Equal1("Duggu",11);
Equal1 ob2=new Equal1("Ayush",12);
Equal1 ob3=new Equal1("Duggu",11);
Equal1 ob4=ob1;
System.out.println(ob1.equals(ob2));
System.out.println(ob1.equals(ob3));
System.out.println(ob1.equals(ob4));
}
}
/* output==> False, false,true;
because it compare refernce not value. */
