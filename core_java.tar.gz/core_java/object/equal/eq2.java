class Equal2
{
 String name;
int rollno;
Equal2(String name,int rollno)
{
this.name=name;
 this.rollno=rollno;
}

public boolean equals(Object obj)
{
String name=this.name;
int rollno=this.rollno;
 Equal2 s=(Equal2)obj;
String name2=s.name;
int rollno2=s.rollno;
if(name.equals(name2) && rollno==rollno2)
{
 return true;
}
else
{   
 return false;
} 
} 
  public static void main(String arr[])
{
 Equal2  ob1=new Equal2("Duggu",11);
Equal2  ob2=new Equal2("Sulabh",12);
Equal2  ob3=new Equal2("Duggu",11);
Equal2  ob4=ob1;
System.out.println(ob1.equals(ob2));
System.out.println(ob1.equals(ob3));
System.out.println(ob1.equals(ob4));
}
}








//In if statement string class equals method is called because it is string comparision 
//String class eqalas method compare content not reference.
