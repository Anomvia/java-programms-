class Demo
{
 int a=5;
static int b=10;



 public static void main(String arr[])
 {
  Demo ob=new Demo();
   System.out.println(Demo.b); 
    System.out.println(ob.a);
  }
 }
