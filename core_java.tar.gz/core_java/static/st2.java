class Demo
{
 int a;
static int b=10;

void read(int k)
{
  a=k;
 }
 void show()
  {
   System.out.println("Value of a="+a);
   System.out.println("Value of static b ="+b);
   }

 public static void main(String arr[])
 {
  Demo ob1=new Demo();
  Demo  ob2=new Demo();
   ob1.read(7);
   ob1.show();
   ob2.show();
    }
 }
