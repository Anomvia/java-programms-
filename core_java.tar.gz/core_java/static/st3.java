class Demo
{
 int a;
static int b=10;

static void read()
{
  System.out.println("Static method run");
 }
 

 public static void main(String arr[])
 {
 // Demo ob1=new Demo();
 // Demo  ob2=new Demo();
   
  read();   }
 }
