class Demo
{
  static
  {
   System.out.println("Hello from static block");
   }
 } 
