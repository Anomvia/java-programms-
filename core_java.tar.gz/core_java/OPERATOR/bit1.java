class Demo
{
 public static void main(String arr[])
 {
  int a=10;
  int b=7;
  
    System.out.println(a&b);
    System.out.println(a|b);
    System.out.println(a<<2);
  }
}
