class Demo
{
 public static void main(String arr[])
 {
  int a=10;
  int b=20;
  int c=30;
  String s="abc";
  System.out.println(a+b+c); //60
   System.out.println(a+b+s);  //30abc
    System.out.println(s+(a+b)); //abc30  //abc1020
      System.out.println(a+b+s+c); //1020abc30
  }
}

