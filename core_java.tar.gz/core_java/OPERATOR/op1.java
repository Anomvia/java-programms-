class Demo
{
 public static void main(String arr[])
 {
  int a=7;
  a++;
  System.out.println(a);
   System.out.println(a++);
   a--;
    System.out.println(a);
  }
}
