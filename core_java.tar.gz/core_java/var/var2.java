class VarDemo {
    
    void sum(int...a)
    {
        int total=0;
        for(int k:a)
        {
            total=total+k;
        }
        System.out.println("Total="+total);
    }
    
    public static void main(String arr[]) {
        
        VarDemo ob=new VarDemo();
        ob.sum();
        ob.sum(10);
        ob.sum(10,20);
        ob.sum(10,20,30);
    }
}
