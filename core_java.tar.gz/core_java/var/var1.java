class VarDemo {
    
    void sum(int...a)
    {
      System.out.println("Sum method called");
    }
    
    public static void main(String arr[]) {
        
        VarDemo ob=new VarDemo();
        ob.sum();
        ob.sum(10);
        ob.sum(10,20);
        ob.sum(10,20,30);
    }
}
