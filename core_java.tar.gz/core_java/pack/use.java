import mypack.Demo;
class use
{
 public  static void main(String arr[])
  {
   Demo ob=new Demo();
   ob.show(8);
    }
 }
