package mypack;
public class Demo
{
  public void show(int a)
 {
  if(a%2==0)
  {
    System.out.println("Number is even");
  }else
  {
 System.out.println("Number is odd");
 }
}
}
