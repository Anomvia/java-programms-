import java.util.*;
class Bank
{
//@SuppressWarnings("unchecked")
 public ArrayList  get_Customers_Details()
{
 ArrayList al=new ArrayList();
al.add("Duggu");
al.add("khushi");
al.add("Ayush");
return al;
  }
} 
class Test
{
 @SuppressWarnings("unchecked")
 public static void main(String arr[])
{
ArrayList al=new ArrayList();
al.add("Duggu");
al.add("khushi");
al.add("Ayush");
 System.out.println(al);
 }
}
