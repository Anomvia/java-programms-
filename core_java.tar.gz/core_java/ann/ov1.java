//@override annotatoin
class Db_Driver
{
  public void getDriver()
 {
   System.out.println("Type-1 driver");
  }
}
class New_Db extends Db_Driver
{
@Override
public void geTDriver()
{
 System.out.println("Type-4 driver");
 }
 
  }

class Test
{
public static void main(String arr[])
 {
  Db_Driver db=new New_Db();
  {
    db.getDriver();
   }
 }
}
 
