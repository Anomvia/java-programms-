import java.util.StringJoiner;

 class Strnew {
    public static void main(String[] args) {
        
        StringJoiner jn=new StringJoiner(",","{","}");
        jn.add("Good").add("Morning").add("class!!!!");
        System.out.println(jn);
    }
 }
 
//{Good,Morning,class!!!!}

