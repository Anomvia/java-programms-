import java.util.StringJoiner;

 class Strnew {
    public static void main(String[] args) {
        
        StringJoiner jn=new StringJoiner(",");
       // jn.add("hello").add("class").add("Welcome");
        jn.add("java");
        jn.add("virtual");
        jn.add("Machine");
        System.out.println(jn);
      }  }
  //java,virtual,Machine
