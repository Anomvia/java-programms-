class Demo2 
{ 
 public static void main(String ar[])
  {
    float a=10;
   int b=(int)a;
   System.out.println("Value of b="+b);
   
   char c=ar[0].charAt(0);
   System.out.println(c);
   }
 }
