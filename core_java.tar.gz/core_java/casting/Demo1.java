class Demo1
{ 
 public static void main(String ar[])
  {
   double d=12.34/2;
   System.out.println("Result="+d);
   int a=10;
   float b=a;
   System.out.println("Value of b="+b);
   }
 }
