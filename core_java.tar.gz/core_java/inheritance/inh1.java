 class Demo
{
  int a;
   void show()
   {
    System.out.println(" Hello from Base class show");
     }
  protected   void disp()
   {
    System.out.println(" Hello from Base disp");
     }
     }
     
     
     class Abc extends Demo
  {
  protected void disp()
   {
    System.out.println(" This is now change disp() ");
    super.disp();
  
      }
     
   public static void main(String arr[])
   {
     Abc ob1=new Abc();
      ob1.show();     
       ob1.disp();
         }
     }  
 
 
 
