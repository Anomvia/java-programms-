  class Demo
  {
   int num=10;
   Demo()
   {
    System.out.println("Super default constructor");
     }
   }
   class Abc extends Demo
   {
    int num=20;
    Abc()
    {
    super();
    }
    void show()
    {
     System.out.println(num); 
     //System.out.println(super.num);
    }
    public static void main(String arr[])
     {
      Abc ob=new Abc();
      ob.show();
       }
    }
