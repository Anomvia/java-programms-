  class Demo
  {
   int num=10;
   }
   class Abc extends Demo
   {
    int num=20;
    void show()
    {
     System.out.println(num); 
     System.out.println(super.num);
    }
    public static void main(String arr[])
     {
      Abc ob=new Abc();
      ob.show();
       }
    }
