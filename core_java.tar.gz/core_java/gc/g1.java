class Demo
{
 protected void finalize() throws Throwable
{
 System.out.println("Finalaize called");
System.out.println("Destroyed Object-"+this);
 }
 public static void main(String arr[])
 {
  Demo ob1=new Demo();
Demo ob2=new Demo();

 ob1=null;
System.gc();
 ob2=null;
Runtime.getRuntime().gc(); 
 }
 }
