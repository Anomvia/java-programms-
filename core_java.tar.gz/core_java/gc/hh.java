import java.util.Scanner;
class RunDemo
{
 public static void main(String arr[])
 {
     Runtime r=Runtime.getRuntime();
System.out.println("Total Memory=" + r.totalMemory());
System.out.println("Total Free memory=" + r.freeMemory());
  for(int i=0;i<=20;i++)
 { 
 Scanner sc=new Scanner(System.in);
  sc=null;
    }
System.out.println("Total Free memory=" + r.freeMemory());
  r.gc();
System.out.println("Total Free memory=" + r.freeMemory());
   }
 }

